export class Machines {

    _id: string;
    code: String;
    description: String;
    rent: Number;
    maxHours: Number
    
}