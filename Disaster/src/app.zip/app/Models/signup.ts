export class signup {
    constructor(
        firstname:string,
        lastname:string,
        email: string,
        password: string,
        role:string) { }

}