export class signin {
    constructor(
        email: string,
        password: string) { }

}