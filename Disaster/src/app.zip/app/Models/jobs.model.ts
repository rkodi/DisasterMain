export class job {
    
    _id: string;
    code: string;
    description: string;
    rate: number;
    maxHours: number
}